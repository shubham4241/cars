import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'cars';
  // car: { model: string, year: number, price:number } = 
  //      {
  //       model: "Honda Accord",
  //       year: 2022,
  //       price:38050,
  //       abc:{}
  // }

//   car1 = 
// {
//     abc: {

//     }
//   }

  
  
}
