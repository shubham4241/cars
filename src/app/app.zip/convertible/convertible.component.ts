import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-convertible',
  templateUrl: './convertible.component.html',
  styleUrls: ['./convertible.component.css']
})
export class ConvertibleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
